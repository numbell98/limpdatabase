-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(1)
addappid(2)
addappid(3)
addappid(6)
addappid(8)
addappid(9)
addappid(40)
addappid(41,0,"025b3eca6aed746732da1e3669452167afa6df93a4a732f76f82776d63c11661")
addappid(42,0,"dbf1cb61d0e85bc273f75e5783379604a9535d51d890ba3ac4bf33a3179e5d1b")
addappid(43,0,"aa98bee53ed3ef9af322ce948ccb6d047ffb1db406454f26bc1cd4c00f524059")
addappid(44,0,"60eddbf739a2d595b66ba0bda767de73f05fb962e93aa5028f697532a9e99c8d")
addappid(45,0,"219e96e5fd5ef98d939303b989c41d8a4fc282923f4ba5c2626f689b709b623f")
addappid(72)
addappid(73)
addappid(74)
addappid(75)
addappid(77)
addappid(78)
addappid(79)
addappid(141)
