-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(1)
addappid(2)
addappid(3)
addappid(6)
addappid(8)
addappid(9)
addappid(30)
addappid(31,0,"4d5feb3d2283c50f9d90f8d2b785f4ff4aa057829acf3fc00ce69326b14ca65a")
addappid(32,0,"8e2fcb16f1a7e99aec4c037da7536085d6342de4b87320cf723f1a7cf30af352")
addappid(33,0,"2863b8218868795c976bcda78604dd813861c9c8859fb751c71b38fd95c852e2")
addappid(34,0,"beca474197ac3935ab475f20ccb8c6813e15a99335dd419fc384881482b3926f")
addappid(35,0,"0a83a4119e657daa861fc0e3b4cb4229ea3cc346c5fdeeda090e69754bef9d20")
addappid(72)
addappid(73)
addappid(74)
addappid(75)
addappid(77)
addappid(78)
addappid(79)
addappid(141)
