-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(1)
addappid(2)
addappid(3)
addappid(6)
addappid(8)
addappid(9)
addappid(50)
addappid(51,0,"cfb8898867eae1901bce2e85444f2cf5c689d4806c137692f0f370868d0b4f03")
addappid(52,0,"9f4f1e296fdb38bfbc27c771600e598198839f9503135a4b2b813536c48c516c")
addappid(53,0,"3ff910cb008ad4571814eb9367e42406cc39e0e6096ed428cdc5b182bb7874b4")
addappid(56,0,"4f56f187e00ad0aafbc1a33ce5e8f39c68ffd641e19596fb63395ec0fb71c758")
addappid(72)
addappid(73)
addappid(74)
addappid(75)
addappid(77)
addappid(78)
addappid(79)
addappid(96)
addappid(141)
