-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(2160220)
addappid(2160222,0,"93030989b69aab728a4f0f2ca3603f6baf6e194d193a607f730b93a4c4e9c855")
